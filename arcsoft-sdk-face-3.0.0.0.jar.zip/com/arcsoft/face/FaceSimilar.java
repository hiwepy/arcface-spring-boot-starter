//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.arcsoft.face;

/**
 * 相似度信息类
 */
public class FaceSimilar {
    /**
     * 相似度值
     */
    float score = 0.0F;

    /**
     * 创建一个空的相似度对象
     */
    public FaceSimilar() {
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }
}
